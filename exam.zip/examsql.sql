SELECT * FROM users;

INSERT INTO tv_shows(title,network,release_date,description,users_id)
VALUES('the office','nbc','whenver','goodshow',1);

SELECT * FROM tv_shows;
